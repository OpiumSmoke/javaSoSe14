public class Main{

public static void main(String[] args){

//	BruteForce force = new BruteForce();
//	force.solve();
	
	Backtracking bt = new Backtracking();
	
	bt.solve();


}

}